import React from 'react';
import {Container,Row,Col} from 'react-bootstrap';
import InputForm from './InputForm';
import InputInfo from './InputInfo';


function Contact() {
    return (
        <>


        <Container>
            <Row>
                <Col  xs={{order:2,span:12}} lg={{order:1,span:7}}>
                <h1>Submit your details</h1>
                <InputForm />
                </Col>
                <Col className="content-info" xs={{order:1,span:12}} lg={{order:2,span:5}}>
                <InputInfo /> 
                </Col>
            </Row>
        </Container>
        </>
    )
}

export default Contact