import React from 'react'
import {Container,Row} from 'react-bootstrap';
import {FaEnvelope,FaPhone,FaMapMarkerAlt} from "react-icons/fa";


function InputInfo() {
    return (
        <>
            <Container>
                <Row>
                    <FaEnvelope />
                    <p>hello@yay.com</p>
                </Row>
                <Row>
                    <FaPhone />
                    <p>123 456 7890</p>
                </Row>
                <Row>
                    <FaMapMarkerAlt/>
                    <div>
                        <p>123 Some street</p>
                        <p>Somewhere</p>
                        <p>Some City</p>
                        <p>10000</p>
                    </div>
                </Row>
            </Container>
        </>
    )
}

export default InputInfo