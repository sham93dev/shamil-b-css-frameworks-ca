import React from 'react'
import {Tabs,Tab,Card} from 'react-bootstrap';
import TabImg1 from './img/tab-image.png';
import {FaFacebookF,FaTwitter} from "react-icons/fa";





function InputTabs() {
    return (
        <>
        <Tabs defaultActiveKey="first">
            <Tab eventKey="first" title="First">
                <Card>
                    <Card.Body>
                        <Card.Img className="tabimg" variant="top" src={TabImg1} />
                        <Card.Text>
                        Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. 
                        Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                        </Card.Text>
                        <Card.Link href="#" className="icons-input" >
                            <p classNAme="mr-3">SHARE</p>
                                <FaFacebookF className ="mr-4" />
                                <FaTwitter  className="mr-4" />
                            </Card.Link>
                    </Card.Body>
                </Card>
            </Tab>
            <Tab eventKey="second" title="Second">
                <Card>
                <Card.Body>
                        <Card.Img className="tabimg" variant="top" src={TabImg1} />
                        <Card.Text>
                        Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. 
                        Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                        </Card.Text>
                        <Card.Link href="#" className="icons-input" >
                            <p classNAme="mr-3">SHARE</p>
                                <FaFacebookF className ="mr-4" />
                                <FaTwitter  className="mr-4" />
                            </Card.Link>
                    </Card.Body>
                </Card>
            </Tab>
            <Tab eventKey="third" title="Third">
                <Card>
                <Card.Body>
                        <Card.Img className="tabimg" variant="top" src={TabImg1} />
                        <Card.Text>
                        Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. 
                        Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                        </Card.Text>
                        <Card.Link href="#" className="icons-input" >
                            <p classNAme="mr-3">SHARE</p>
                                <FaFacebookF className ="mr-4" />
                                <FaTwitter  className="mr-4" />
                            </Card.Link>
                    </Card.Body>
                </Card>
            </Tab>
        </Tabs>
        </>
    )
}

export default InputTabs