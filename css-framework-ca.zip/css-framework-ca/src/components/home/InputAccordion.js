import React from 'react';
import {Accordion,Card,Button} from 'react-bootstrap';
import TabImg1 from './img/tab-image.png';
import {FaFacebookF,FaTwitter} from "react-icons/fa";


function InputAccordion() {
    return (
        <>
            <Accordion defaultActiveKey="0">
                <Card>
                    <Card.Header>
                        <Accordion.Toggle as={Button} variant="link" eventKey="0">
                            First
                        </Accordion.Toggle>
                    </Card.Header>
                    <Accordion.Collapse eventKey="0">
                        <>
                        <Card.Body className="card-border">
                        <Card.Text>
                                Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                            </Card.Text>
                            <Card.Img variant="top" src={TabImg1} />
                            <Card.Link href="#" className="flex-lg-row mt-5"> 
                            <span class="mr-2">SHARE</span>
                                <FaFacebookF className ="mr-2" />
                                <FaTwitter  className="mr-2" />
                            </Card.Link>
                        </Card.Body>
                        </>
                    </Accordion.Collapse>
                </Card>
                <Card>
                    <Card.Header>
                        <Accordion.Toggle as={Button} variant="link" eventKey="1">
                            Second
                        </Accordion.Toggle>
                    </Card.Header>
                    <Accordion.Collapse eventKey="1">
                        <>
                        <Card.Body className="card-border">
                        <Card.Text>
                                Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                            </Card.Text>
                            <Card.Img variant="top" src={TabImg1} />
                            <Card.Link href="#" className="flex-lg-row mt-5"> 
                            <span class="mr-2">SHARE</span>
                                <FaFacebookF className ="mr-2" />
                                <FaTwitter  className="mr-2" />
                            </Card.Link>
                        </Card.Body>
                        </>
                    </Accordion.Collapse>
                </Card>
                <Card>
                    <Card.Header>
                        <Accordion.Toggle as={Button} variant="link" eventKey="2">
                            Third
                        </Accordion.Toggle>
                    </Card.Header>
                    <Accordion.Collapse eventKey="2">
                        <>
                        <Card.Body className="card-border">
                        <Card.Text>
                                Morbi eget efficitur turpis. Vivamus pellentesque tortor massa, venenatis pharetra leo laoreet a. Nullam non eleifend justo, a ullamcorper turpis. Cras vehicula pharetra lectus non maximus. Sed condimentum mattis rhoncus. 
                            </Card.Text>
                            <Card.Img variant="top" src={TabImg1} />
                            <Card.Link href="#" className="flex-lg-row mt-5"> 
                            <span class="mr-2">SHARE</span>
                                <FaFacebookF className ="mr-2" />
                                <FaTwitter  className="mr-2" />
                            </Card.Link>
                        </Card.Body>
                        </>
                    </Accordion.Collapse>
                </Card>
            </Accordion>
        </>
    )
}

export default InputAccordion