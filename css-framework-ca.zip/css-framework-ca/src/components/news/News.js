import React from 'react';
import PagiNations from './InputPaginations';
import InputCards from './InputCards';
import Container from 'react-bootstrap/Container';


function News() {
    return (
        <>
            <Container>
                <h1>News</h1>
            </Container>

            <Container>
                <PagiNations />
            </Container>

            <Container className="card-container">
                <InputCards />
            </Container>

            <Container>
                <PagiNations/>
            </Container>
        </>
    )
}

export default News