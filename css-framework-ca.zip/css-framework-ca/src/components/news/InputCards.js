import React from 'react';
import {Row, Card, Button} from 'react-bootstrap';
import Img1 from './img/news-1.png';
import Img2 from './img/news-2.png';
import Img3 from './img/news-3.png';
import Img4 from './img/news-4.png';
import Img5 from './img/news-5.png';
import Img6 from './img/news-6.png';
import Img7 from './img/news-7.png';
import Img8 from './img/news-8.png';

function InputCards() {
    return (
        <>
        <Row>
            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img1} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img2} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img3} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img4} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img5} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img6} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img7} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>

            <Card style={{ width: '16rem' }}>
                <Card.Img variant="top" src={Img8} />
                <Card.Body>
                    <Card.Title>Nunc porttitor vel</Card.Title>
                    <Card.Text>
                        Nunc malesuada eget est fringilla dapibus.
                    </Card.Text>
                    <Button className="newsbutton" variant="primary">MORE</Button>
                </Card.Body>
            </Card>
        </Row>
        
        </>
    )
}

export default InputCards