import React from 'react';
import "./sass/style.scss";
import { BrowserRouter as Router, Switch, Route, } from "react-router-dom";
import Home from './components/home/Home';
import News from './components/news/News';
import Contact from './components/contact/Contact';
import {Nav, Navbar,Form, FormControl,Button,Card} from "react-bootstrap";
import { Container, Row, Col } from 'react-bootstrap';
import { FaYoutube, FaVimeoV } from "react-icons/fa";


function App() {
  return (
    <Router>
      <Navbar bg="light" expand="lg">
  <Navbar.Brand href="/" className="logo">The YAY Company</Navbar.Brand>
  <Navbar.Toggle aria-controls="basic-navbar-nav" />
  <Navbar.Collapse id="basic-navbar-nav">
    <Nav className="mr-auto">
    <Nav.Link className= { window.location.pathname==="/"?"active":""}  href="/">Home</Nav.Link>
      <Nav.Link className= { window.location.pathname==="/news"?"active":""} href="/news">News</Nav.Link>
      <Nav.Link className= { window.location.pathname==="/contact"?"active":""} href="/contact">Contact</Nav.Link>
    </Nav>

    <Form inline>
      <FormControl type="text" placeholder="Search" className="mr-sm-2" />
      <Button className="pinkbtn">Go</Button>
    </Form>
  </Navbar.Collapse>
</Navbar>
      
        <Switch>
          <Route exact path="/">
            <Home />
          </Route>
          <Route path="/news">
            <News />
          </Route>
          <Route path="/contact">
            <Contact />
          </Route>
        </Switch> 


      <Card.Footer className="footer">
        <Container className="footer-size" >
          <Row className="container-info">
            <Col >
              <FaVimeoV className="fa-vimeo-v" />
              <FaYoutube className="fa-youtube"/>
            </Col>
            <Col>
              hello@yay.com
            </Col>
            <Col>
              Copyright 2020
            </Col>
          </Row>
        </Container>
      </Card.Footer>





    </Router>

    
  );
}

export default App;

